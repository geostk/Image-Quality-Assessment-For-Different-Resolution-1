The parameter in imagecreate_*.txt
b represents blur; the parameter after it represents blur method and the integer after block means the block size.
c represents jpeg compression and integer after it represent jpeg compreesion quality score.
n represents noise; the parameter after it represents noise type; the mean of all noise is zero and variance is the real number after var.

The parameter in rate_result_average_*.txt is the subjective score of images in the corresponding folder.